## Predictor's Next 50 Proteins
$ bash PDB.sh 
to acquire a set of 50 proteins that can be used for testing the predictor.
